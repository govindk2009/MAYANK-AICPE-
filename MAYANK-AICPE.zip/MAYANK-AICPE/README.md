# MAYANK AICPE

Frontend starter for an online learning and examination portal.

## GitHub Pages
Upload these files to a GitHub repository and enable **Settings → Pages → Deploy from branch**.

## Important
The current Google button is UI/demo only. Real Google Sign-In requires Google OAuth/Google Identity Services and a suitable backend or authentication provider. Do not store real passwords in this static frontend.

Planned modules:
- Google authentication
- Student registration/login
- Courses
- Online MCQ exams
- Results
- Certificate generation
- Certificate verification
- Admin dashboard

Certificates should only claim recognition/accreditation that the issuing organization is actually authorized to provide.
