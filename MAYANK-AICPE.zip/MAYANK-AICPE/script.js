const form=document.getElementById('loginForm');
const googleBtn=document.getElementById('googleBtn');
const message=document.getElementById('message');

form.addEventListener('submit',(e)=>{
  e.preventDefault();
  message.textContent='Demo login submitted. Backend authentication will be connected next.';
});

googleBtn.addEventListener('click',()=>{
  message.textContent='Google Sign-In UI is ready. Real Google OAuth needs configuration.';
});

document.getElementById('forgot').addEventListener('click',(e)=>{
  e.preventDefault();
  message.textContent='Password recovery will be connected to the backend.';
});

document.getElementById('signup').addEventListener('click',(e)=>{
  e.preventDefault();
  message.textContent='Registration page will be added in the next step.';
});
